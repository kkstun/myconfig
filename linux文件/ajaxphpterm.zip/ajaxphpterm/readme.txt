------------------------------------------------------------------------------

Welcome to ajaxphpterm!  To implement this, just unzip the files and then upload the ajaxphpterm folder to your website (via ftp).  Then point your browser to the index.php file and you will be up and running!

You also may want to add an .htaccess file to the ajaxphpterm folder to limit accessibility to it (since users will essentially have shell access to your entire site).  This enables you to password protect the folder.  If you need help with that, just google .htaccess or .htpasswd. 

------------------------------------------------------------------------------

Your help is appreciated in making ajaxphpterm better.  Some TODOs:

-Allow for editing of files (using vi, vim, emacs, etc.)
-Allow for viewing man pages
-Password authentication built-in
-Better communication with rpc.php (perhaps using XML instead of simple text commands)
